package com.example.demo;
 
import org.springframework.web.bind.annotation.*;
import java.util.ArrayList;
import java.util.List;
 
@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "*")
public class CotizacionController {
 
    // ── Clase interna Cotizacion ───────────────────────
    static class Cotizacion {
        public int id;
        public String email;
        public String fecha;
 
        public Cotizacion(int id, String email, String fecha) {
            this.id    = id;
            this.email = email;
            this.fecha = fecha;
        }
    }
 
    // ── Array donde se guardan las cotizaciones ────────
    private static final List<Cotizacion> cotizaciones = new ArrayList<>();
    private static int contador = 1;
 
    // ── POST /api/cotizaciones → guarda un correo ──────
    @PostMapping("/cotizaciones")
    public Cotizacion guardarCotizacion(@RequestBody java.util.Map<String, String> body) {
        String email = body.get("email");
        String fecha = java.time.LocalDateTime.now()
            .format(java.time.format.DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm"));
        Cotizacion c = new Cotizacion(contador++, email, fecha);
        cotizaciones.add(c);
        return c;
    }
 
    // ── GET /api/cotizaciones → devuelve todas ─────────
    @GetMapping("/cotizaciones")
    public List<Cotizacion> getCotizaciones() {
        return cotizaciones;
    }
}